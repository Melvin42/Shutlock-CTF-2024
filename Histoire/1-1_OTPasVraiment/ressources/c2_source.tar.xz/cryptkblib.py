import random

class MyRandomGenerator():


    def __init__(self):
        self.state = [random.randint(0,255) for s in range(8)]     


    def getrandombyte(self):

        x = 42

        for i in range(8):
            x ^= (self.state[i] << 19)

        y = ((self.state[0]) << 7)

        self.state[0] = self.state[1]
        self.state[1] = self.state[2]
        self.state[2] = self.state[3] 
        self.state[3] = self.state[4]
        self.state[4] = self.state[5]
        self.state[5] = self.state[6]
        self.state[6] = self.state[7]
        self.state[7] = ((self.state[7] + self.state[0]) + (x ^ y)) % 0xff

        return self.state[7]


    def getrandombytes(self, n):
        return [self.getrandombyte() for i in range(n)]



class MyLogFile():

    """MyLogFile Structure

    # Header
     - Magic Bytes
     - Chunk Size
     - Metadata Chunks count
     - Chunks count
     
    #Data
     - Crypted Metadata Chunks (aligned on chunk_size)
     - Crypted Data Chunks (aligned on chunk_size)
     
    # Footer
     - EOF (aligned on 16 bytes)


    """
    def __init__(self, filename, header_size, chunk_size, magic_bytes, eof):
        
        self.filename = filename
        self.header_size = header_size
        self.chunk_size = chunk_size
        self.magic_bytes = magic_bytes
        self.eof = eof

        self.metadata_chunk_count = 0
        self.data_chunk_count = 0
        self.file = None
        
    def create(self):

        self.file = open(self.filename, "wb")

        self.file.write(self.magic_bytes)

        self.file.write(int.to_bytes(self.chunk_size, 2))
        self.file.write(int.to_bytes(self.metadata_chunk_count, 2))
        self.file.write(int.to_bytes(self.data_chunk_count, 2))

        return self.file


    def save(self):

        self.file.write(self.eof.ljust(self.header_size, b'\0'))

        self.file.seek(12)
        self.file.write(int.to_bytes(self.metadata_chunk_count, 2))
        self.file.write(int.to_bytes(self.data_chunk_count, 2))

        self.file.close()
        
        return None


    def write(self, data, chunk_type):

        self.file.write(data.ljust(self.chunk_size, b'\0'))

        if (chunk_type == "meta"):
            self.metadata_chunk_count += 1

        elif (chunk_type == "data"):
            self.data_chunk_count += 1


        return 1
