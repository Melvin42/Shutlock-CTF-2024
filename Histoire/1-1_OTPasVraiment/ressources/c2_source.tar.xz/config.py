from secret import flag
from secret import telegram_channel


# Server configuration

HOST = '0.0.0.0'
PORT = 1337


# Log File Config

header_size = 16
chunk_size = 256

magic_bytes = b"CrypTKBLog"

metadata1 = f"""
---- CONFIDENTIAL ----
This file is destinated to be share with members only.
""".encode("utf-8")

metadata2 = f"""
---- NEW MEMBERS ----
For new members, you can get more informations on our Telegram channel: {telegram_channel}
Here is a gift for you : {flag}
""".encode("utf-8")

metadata3 = f"""
---- INFORMATIONS ----
Now, you can check the list of machines that we comprosimed :
""".encode("utf-8")

eof = b"CrypTKBEOF"


filename = "logs"
