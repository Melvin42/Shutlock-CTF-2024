# Placeholder for flag and telegram_channel

flag = "A" * 44

telegram_channel = "B"*29

